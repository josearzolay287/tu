
  $(document).ready(function() {
   if ($('#profesor').length) {
  // si existe
  console.log('hola mundo')
          return false; 
} else {
  // no existe
  console.log('hola mundo2')
          return false; 
}
  });  
 